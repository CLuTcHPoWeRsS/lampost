const uf_ver_string = "UF 1.0";
var uf_debug = false;

// ---- Introduction
// Based on actual fairdyne source
Scene.prototype.selectScene = function(name, data) {

	this.scene_state = name;
	this.scene_time = 0;

	switch(this.scene_state) {
		case "splash":
			break;
		case "gameplay":
            undyne.queue_text([
				{ text: "So you want to spar\nwith me, huh?" },
				{ text: "As if I could ever\ndefeat YOU..." },
                { text: "You're just a dirty\nhacker, aren't you?" },
                { text: "Oh, it doesn't\nmatter. Torment me\nall you like." },
			], uf_begin_game);
			gameplay_stage.alpha = 0;
			break;
	}

}

function uf_begin_game() {
    menu = new Menu();
    menu.select_text.text = "Select an unfairness level."
    menu.options = ["hard", "genocide", "aprilfools"];
    menu.normal_text_text = "Frisk? That's a nice name.";
    menu.hard_text_text = "Greetings. I am Chara.";
    menu.genocide_text_text = "Jerry came, too.";
    menu.show();
    menu.updateLove();
}

Menu.prototype.updateLove = function() {
    love_text.text = uf_ver_string.substring(3);
	heart.setMaxHP(1);
}

const uf_undyne_responses = ["I'll show you how\ndetermined monsters\ncan be! Even if it's\njust to bore you!",
                             "I, UNDYNE, will\nstrike... oh, who am\nI kidding. I can't.\nNobody can.",
                             "You deserve this.\nIt's too bad I can't\ngive it to you."]

Menu.prototype.select = function() {
	this.hide();
	se_menu_select.play();
	undyne.queue_text([{text: uf_undyne_responses[this.current_option]}], gamestate.restartGame.bind(gamestate, this.options[this.current_option]));
}

// ---- Tools

function uf_make_invulnerable() {
	setInterval(function() { heart.invincibility = 1000; }, 250);
}

// ---- Signals

Heart.prototype._uu_takeDamage = Heart.prototype.takeDamage;

Heart.prototype.takeDamage = function (damage) {
    if (this.invincibility > 0) return;
    console.warn("UnfairFrisk: took damage!");
    this._uu_takeDamage(damage);
}

// ---- Arrows and shield attack, plus rotating heart

const uf_arrow_dir_names = ["???", "down", "left", "up", "right"];
const uf_heart_dir_names = ["!!!", "right", "down", "left", "up"];
const uf_turntype_names = ["straight", "Xclock", "revs", "revs", "clock"];

Arrow.prototype._uu_update = Arrow.prototype.update;
Heart.prototype._uu_update = Heart.prototype.update;

Arrow.prototype.update = function (delta_ms) {
	this._uu_update(delta_ms);
	if (this.target_time <= 0) {
		// Directions: 3=up 4=right 1=down 2=left
		var nshielddir = ((this.direction + turntype_rotation[this.turntype]) % 4);
		heart.shield_dir = heart.abs_shield_dir = nshielddir;
    	heart.shield_sprite.rotation = Math.PI / 2 * (1 + heart.shield_dir);
        if (uf_debug) console.log("UnfairFrisk: Moving shield to " + uf_heart_dir_names[nshielddir + 1] + " to block a " + uf_turntype_names[this.turntype] + " arrow from " + uf_arrow_dir_names[this.direction]);
    }
}

Heart.prototype.update = function (delta_ms) {
    var rotation = this.shield_sprite.rotation;
    this._uu_update(delta_ms);
    this.shield_sprite.rotation = rotation;

    // Rotating heart
    this.sprite.rotation += 1 / (delta_ms * 8) * Math.PI;
    this.sprite.rotation %= 2 * Math.PI;
}

// ---- Pike attack (from top and bottom)

Pike.prototype._uu_update = Pike.prototype.update;

var pikes_in_cols = [undefined, 0, 0, 0];
var x_for_cols = [undefined, 299, 320, 341];

Pike.prototype.update = function (delta_ms) {
    var recalc_dodge = false;

    this.active_time += delta_ms;
    if (this.active_time >= this.appear_time && !this.shot) {
        pikes_in_cols[this.initial_position] += 1;
        console.log("added pike from " + this.initial_position + ":   " + pikes_in_cols);
        recalc_dodge = true;
    }

    this._uu_update(0); // active_time was updated earlier

    if ((this.active_time >= this.appear_time + 150 || this.collidesWithHeart() || this.removed || this.active_time > spear_total_time) && !this.uf_removed) {
        this.uf_removed = true;
        pikes_in_cols[this.initial_position] -= 1;
        console.log("removed pike from " + this.initial_position + ": " + pikes_in_cols);
        recalc_dodge = true;
    }
    
    // bug preventer!
    if (pikes_in_cols[1] < 0) pikes_in_cols[1] = 0;
    if (pikes_in_cols[2] < 0) pikes_in_cols[2] = 0;
    if (pikes_in_cols[3] < 0) pikes_in_cols[3] = 0;

    if (recalc_dodge) uf_dodge_pikes(this.initial_position);
}

function uf_dodge_pikes(pos) {
    // compute & apply new location for heart
    // using <= 0 checks even though it should never be < 0 to prevent bugs
    var col_to_visit = 0;
    if (pikes_in_cols[1] <= 0) {
        col_to_visit = 1;
    } else if (pikes_in_cols[2] <= 0) {
        col_to_visit = 2;
    } else if (pikes_in_cols[3]<= 0) {
        col_to_visit = 3;
    } else {
        console.error("UnfairFrisk: couldn't dodge a pike attack in col " + pos + " with " + pikes_in_cols);
        return;
    }
    if (uf_debug) console.log("UnfairFrisk: moving to pike-col " + col_to_visit + " with " + pikes_in_cols + ":" + pos);
    heart.setPosition(x_for_cols[col_to_visit], 315);
}

// ---- Spears attack (sides)

Spear.prototype._uu_update = Spear.prototype.update;

function uf_getdir() {
    var rbool = Math.round(Math.random()) == 0;
    return rbool ? 1 : -1;
}

Spear.prototype.update = function(delta_ms) {
    if (this.shot) {
        var dir_x = uf_getdir(), dir_y = uf_getdir();
        
		this.pos_x += this.direction.x * SPEAR_SPEED * delta_ms;
		this.pos_y += this.direction.y * SPEAR_SPEED * delta_ms;
        do {
            heart.setPosition((heart.pos_x + dir_x) % (box.right - HEART_SIZE / 2),
                              (heart.pos_y + dir_y) % (box.bottom - HEART_SIZE / 2));
        } while (this.collidesWithHeart()) 
        this.pos_x -= this.direction.x * SPEAR_SPEED * delta_ms;
        this.pos_y -= this.direction.y * SPEAR_SPEED * delta_ms;
    }

    this._uu_update(delta_ms);
}
